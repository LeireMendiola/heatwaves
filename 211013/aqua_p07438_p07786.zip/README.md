# AppEEARS Point Sample Extraction Readme  

## Table of Contents  

1. Request Parameters  
2. Request File Listing  
3. Point Sample Extraction Process  
4. Data Quality  
    4.1. Moderate Resolution Imaging Spectroradiometer (MODIS)  
    4.2. NASA MEaSUREs Shuttle Radar Topography Mission (SRTM) Version 3 (v3)  
    4.3. Gridded Population of the World (GPW) Version 4 (v4)  
    4.4. Suomi National Polar-orbiting Partnership (S-NPP) NASA Visible Infrared Imaging Radiometer Suite (VIIRS)  
    4.5. Soil Moisture Active Passive (SMAP)  
    4.6. MODIS Simplified Surface Energy Balance (SSEBop) Actual Evapotranspiration (ETa)  
    4.7. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  
    4.8. Daymet  
    4.9. U.S. Landsat Analysis Ready Data (ARD)  
    4.10. Ecosystem Spaceborne Thermal Radiometer Experiment on Space Station (ECOSTRESS)  
    4.11. Advanced Spaceborne Thermal Emission and Reflection Radiometer (ASTER) Global Digital Elevation Model (GDEM) Version 3 (v3) and Global Water Bodies Database (WBD) Version 1 (v1)  
    4.12. NASA MEaSUREs NASA Digital Elevation Model (DEM) Version 1 (v1)  
5. Data Caveats  
6. Documentation  
7. Sample Request Retention  
8. Data Product Citations  
9. Software Citation  
10. Feedback  

## 1. Request Parameters  

    Name: Aqua_P07438_P07786  

    Date Completed:** 2021-09-27T09:27:39.974999  

    Id: c167a305-e1f9-4b37-9925-a7b6629ea3c4  

    Details:  

        Start Date: 12-01-2020  

        End Date: 08-31-2021
    
        Layers:  

            LST_Day_1km (MYD11A1.006)  
            LST_Night_1km (MYD11A1.006)  
            QC_Day (MYD11A1.006)  
            QC_Night (MYD11A1.006)  
    
        Coordinates:  

            P07438, 41.92914289, 2.937136227  
            P07439, 41.92811368, 2.950573369  
            P07444, 41.9280067, 3.010987698  
            P07445, 41.92803196, 3.022904113  
            P07447, 41.9278622, 3.047749943  
            P07450, 41.9279317, 3.083680084  
            P07454, 41.92806207, 3.119562169  
            P07457, 41.91906626, 2.901486311  
            P07460, 41.91932636, 2.938749776  
            P07463, 41.91910252, 2.962868915  
            P07466, 41.91902745, 2.998890531  
            P07467, 41.91889185, 3.010769065  
            P07469, 41.91939581, 3.04776775  
            P07471, 41.91937221, 3.05970665  
            P07474, 41.91927642, 3.094956462  
            P07477, 41.91902443, 3.131315316  
            P07481, 41.90992047, 2.878614799  
            P07483, 41.90974478, 2.902139702  
            P07484, 41.90991675, 2.914462441  
            P07489, 41.9100853, 2.938589802  
            P07491, 41.91008658, 2.962464176  
            P07492, 41.90997279, 2.974497871  
            P07495, 41.90991207, 3.010791671  
            P07498, 41.91014595, 3.047471466  
            P07499, 41.91002319, 3.059625591  
            P07501, 41.90952179, 3.131717857  
            P07502, 41.90006692, 2.878524958  
            P07504, 41.90093612, 2.902141096  
            P07512, 41.90059874, 2.986569638  
            P07513, 41.90121198, 2.998637661  
            P07518, 41.90094104, 3.047319976  
            P07520, 41.90092858, 3.07143205  
            P07524, 41.90171741, 3.119344224  
            P07525, 41.90065986, 3.13104862  
            P07528, 41.89153317, 2.926529192  
            P07530, 41.89174455, 2.951433164  
            P07531, 41.89187494, 2.962944959  
            P07533, 41.89191624, 2.987294718  
            P07534, 41.89187143, 3.010475221  
            P07538, 41.89210882, 3.059247296  
            P07540, 41.8920301, 3.071000232  
            P07544, 41.89193892, 3.107247563  
            P07545, 41.89236789, 3.119760778  
            P07546, 41.89208484, 3.131501212  
            P07547, 41.88305591, 2.890356757  
            P07551, 41.88289571, 2.926695772  
            P07555, 41.88288023, 2.974412226  
            P07556, 41.8828463, 2.986850567  
            P07557, 41.88317073, 3.011425963  
            P07562, 41.88274393, 3.071182793  
            P07563, 41.88291595, 3.083247691  
            P07570, 41.87382959, 2.950663417  
            P07571, 41.87383392, 2.962063611  
            P07573, 41.87390247, 2.986683687  
            P07576, 41.87426121, 3.023005416  
            P07581, 41.87398083, 3.095250918  
            P07585, 41.86496999, 2.890218973  
            P07587, 41.86510742, 2.927113722  
            P07589, 41.86503307, 2.938596785  
            P07592, 41.8651931, 3.010663654  
            P07594, 41.8652468, 3.047546683  
            P07595, 41.86455682, 3.059282099  
            P07602, 41.85577583, 2.926401464  
            P07603, 41.85594496, 2.938292241  
            P07608, 41.85586245, 2.998927766  
            P07609, 41.85571786, 3.010577747  
            P07615, 41.84627893, 2.842296708  
            P07616, 41.84722874, 2.914100296  
            P07622, 41.84696125, 3.02341724  
            P07628, 41.83786949, 2.962349831  
            P07632, 41.8380535, 3.022956311  
            P07636, 41.83793793, 3.047406021  
            P07637, 41.83788721, 3.059606761  
            P07642, 41.9702436, 3.216121386  
            P07652, 41.95472398, 3.180196231  
            P07656, 41.94618501, 3.155982741  
            P07661, 41.92811442, 3.203893859  
            P07663, 41.9188493, 3.191780837  
            P07665, 41.91867536, 3.20386381  
            P07667, 41.90085491, 3.155209292  
            P07671, 41.87362699, 3.155384421  
            P07677, 41.82719284, 2.348602923  
            P07678, 41.82703115, 2.361513675  
            P07681, 41.82731083, 2.384704057  
            P07683, 41.82747644, 2.409388933  
            P07687, 41.82818801, 2.44553343  
            P07690, 41.8181411, 2.34863446  
            P07695, 41.81869789, 2.433261705  
            P07697, 41.81813903, 2.457419753  
            P07698, 41.81882428, 2.469141485  
            P07703, 41.80965977, 2.445320031  
            P07704, 41.80966996, 2.456877243  
            P07705, 41.80971986, 2.469481515  
            P07709, 41.79223888, 2.445012898  
            P07711, 41.79198537, 2.469519455  
            P07717, 41.82866899, 2.553899049  
            P07723, 41.82834784, 2.601275995  
            P07724, 41.82883123, 2.613580404  
            P07725, 41.8289795, 2.625718356  
            P07732, 41.82871354, 2.745795305  
            P07733, 41.81927368, 2.480757008  
            P07735, 41.81881765, 2.493607985  
            P07740, 41.81894988, 2.565477336  
            P07741, 41.81898357, 2.576915699  
            P07745, 41.81976314, 2.614140638  
            P07750, 41.8195602, 2.686542845  
            P07752, 41.81974739, 2.783265591  
            P07754, 41.80981833, 2.4811825  
            P07757, 41.81032698, 2.517283319  
            P07759, 41.81013785, 2.541471006  
            P07760, 41.81024094, 2.565680664  
            P07763, 41.81070532, 2.601866984  
            P07766, 41.81110226, 2.626183617  
            P07769, 41.81098688, 2.771015188  
            P07771, 41.81045548, 2.794854407  
            P07772, 41.81012527, 2.807002805  
            P07775, 41.80137783, 2.505457624  
            P07779, 41.80151469, 2.578162142  
            P07782, 41.80121149, 2.601721123  
            P07786, 41.80158592, 2.650337758  
    
    Version: This request was processed by AppEEARS version 2.66  

## 2. Request File Listing  

- Comma-separated values file with data extracted for a specific product
  - Aqua-P07438-P07786-MYD11A1-006-results.csv
- Text file with data pool URLs for all source granules used in the extraction
  - Aqua-P07438-P07786-granule-list.txt
- JSON request file which can be used in AppEEARS to create a new request
  - Aqua-P07438-P07786-request.json
- xml file
  - Aqua-P07438-P07786-MYD11A1-006-metadata.xml  

## 3. Point Sample Extraction Process  

Datasets available in AppEEARS are served via OPeNDAP (Open-source Project for a Network Data Access Protocol) services. OPeNDAP services allow users to concisely pull pixel values from datasets via HTTPS requests. A middleware layer has been developed to interact with the OPeNDAP services. The middleware make it possible to extract scaled data values, with associated information, for pixels corresponding to a given coordinate and date range.

**NOTE:**  

- Requested date ranges may not match the reference date for multi-day products. AppEEARS takes an inclusive approach when extracting data for sample requests, often returning data that extends beyond the requested date range. This approach ensures that the returned data includes records for the entire requested date range.  
- For multi-day (8-day, 16-day, Monthly, Yearly) MODIS and S-NPP NASA VIIRS datasets, the date field in the data tables reflects the first day of the composite period.  
- If selected, the SRTM v3, ASTER GDEM v3 and Global Water Bodies Database v1, and NASADEM v1 product will be extracted regardless of the time period specified in AppEEARS because it is a static dataset. The date field in the data tables reflects the nominal SRTM date of February 11, 2000.  
- If the visualizations indicate that there are no data to display, proceed to downloading the .csv output file. Data products that have both categorical and continuous data values (e.g. MOD15A2H) are not able to be displayed within the visualizations within AppEEARS.  

## 4. Data Quality  

When available, AppEEARS extracts and returns quality assurance (QA) data for each data file returned regardless of whether the user requests it. This is done to ensure that the user possesses the information needed to determine the usability and usefulness of the data they get from AppEEARS. Most data products available through AppEEARS have an associated QA data layer. Some products have more than one QA data layer to consult. See below for more information regarding data collections/products and their associated QA data layers.  

### 4.1. MODIS (Terra, Aqua, & Combined)

All MODIS land products, as well as the MODIS Snow Cover Daily product, include quality assurance (QA) information designed to help users understand and make best use of the data that comprise each product. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values but also the decoded QA information associated with each pixel/data value extracted.  

- See the MODIS Land Products QA Tutorials: <https://lpdaac.usgs.gov/resources/e-learning/> for more QA information regarding each MODIS land product suite.  
- See the MODIS Snow Cover Daily product user guide for information regarding QA utilization and interpretation.  

### 4.2. NASA MEaSUREs SRTM v3 (30m & 90m)  

SRTM v3 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each SRTM pixel, as well as the number of input data scenes used to generate the SRTM v3 data for that pixel.  

- See the user guide: <https://lpdaac.usgs.gov/documents/179/SRTM_User_Guide_V3.pdf> for additional information regarding the SRTM "NUM" file.  

### 4.3. GPW v4  

The GPW Population Count and Population Density data layers are accompanied by two Data Quality Indicators datasets. The Data Quality Indicators were created to provide context for the population count and density grids, and to provide explicit information on the spatial precision of the input boundary data. The data context grid (data-context1) explains pixels with "0" population estimate in the population count and density grids, based on information included in the census documents. The mean administrative unit area grid (mean-admin-area2) measures the mean input unit size in square kilometers. It provides a quantitative surface that indicates the size of the input unit(s) from which the population count and density grids were created.  

### 4.4. S-NPP NASA VIIRS

All S-NPP NASA VIIRS land products include quality information designed to help users understand and make best use of the data that comprise each product. For product-specific information, see the link to the S-NPP VIIRS products table provided in section 5.  

**NOTE:**  

- The S-NPP NASA VIIRS Surface Reflectance data products VNP09A1 and VNP09H1 contain two quality layers: `SurfReflect_State` and `SurfReflect_QC`. Both quality layers are provided to the user with the request results. Due to changes implemented on August 21, 2017 for forward processed data, there are differences in values for the `SurfReflect_QC` layer in VNP09A1 and `SurfReflect_QC_500` in VNP09H1.  
- Refer to the S-NPP NASA VIIRS Surface Reflectance User's Guide Version 1.1: <https://lpdaac.usgs.gov/documents/123/VNP09_User_Guide_V1.1.pdf> for information on how to decode the `SurfReflect_QC` quality layer for data processed before August 21, 2017. For data processed on or after August 21, 2017, refer to the S-NPP NASA VIIRS Surface Reflectance User's guide Version 1.6: <https://lpdaac.usgs.gov/documents/124/VNP09_User_Guide_V1.6.pdf>  

### 4.5. SMAP  

SMAP products provide multiple means to assess quality. Each data product contains bit flags, uncertainty measures, and file-level metadata that provide quality information. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values, but also the decoded bit flag information associated with each pixel/data value extracted. For additional information regarding the specific bit flags, uncertainty measures, and file-level metadata contained in this product, refer to the Quality Assessment section of the user guide for the specific SMAP data product in your request: <https://nsidc.org/data/smap/smap-data.html>  

### 4.6. SSEBop Actual Evapotranspiration (ETa)  

The SSEBop evapotranspiration monthly product does not have associated quality indicators or data layers. The data are considered to satisfy the quality standards relative to the purpose for which the data were collected.

### 4.7. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

The smoothed eMODIS NDVI product does not have associated quality indicators or data layers. The data are considered to satisfy the quality standards relative to the purpose for which the data were collected.  

### 4.8. Daymet  

Daymet station-level daily weather observation data and the corresponding Daymet model predicted data for three Daymet model parameters: minimum temperature (tmin), maximum temperature (tmax), and daily total precipitation (prcp) are available. These data provide information into the regional accuracy of the Daymet model for the three station-level input parameters. Corresponding comma separated value (.csv) files that contain metadata for every surface weather station for the variable-year combinations are also available. <https://doi.org/10.3334/ORNLDAAC/1850>

### 4.9. U.S. Landsat ARD  

Quality assessment bands for the U.S. Landsat ARD data products are produced from Level 1 inputs with additional calculations derived from higher-level processing. A pixel quality assessment band describing the general state of each pixel is supplied with each AppEEARS request. In addition to the pixel quality assessment band, Landsat ARD data products also have additional bands that can be used to evaluate the usability and usefulness of the data. These include bands that characterize radiometric saturation, as well as parameters specific to atmospheric correction. Refer to the U.S. Landsat ARD Data Format Control Book (DFCB): <https://www.usgs.gov/media/files/landsat-analysis-ready-data-ard-data-format-control-book-dfcb> for a full description of the quality assessment bands for each product (L4-L8) as well as guidance on interpreting each band’s bit-packed data values.

### 4.10. ECOSTRESS  

Quality information varies by product for the ECOSTRESS product suite. Quality information for ECO2LSTE.001, including the bit definition index for the quality layer, is provided in section 2.4 of the User Guide: <https://lpdaac.usgs.gov/documents/423/ECO2_User_Guide_V1.pdf>. Results downloaded from AppEEARS contain the requested pixel/data values and also the decoded QA information associated with each pixel/data value extracted. No quality flags are produced for the ECO3ETPTJPL.001, ECO4WUE.001, or ECO4ESIPTJPL.001 products. Instead, the quality flags of the source data are available in the ECO3ANCQA.001 data product and a cloud mask is available in the ECO2CLD.001 product. The `ETinst` layer in the ECO3ETPTJPL.001 product does include an associated uncertainty layer that is provided with each request for ‘ETinst’ in AppEEARS. Each radiance layer in the ECO1BMAPRAD.001 product has a linked quality layer (Data Quality Indicators). ECO2CLD.001 and ECO3ANCQA.001 are separate quality products that are also available for download in AppEEARS.  

### 4.11. ASTER GDEM v3 and Global Water Bodies Database v1  

ASTER GDEM v3 data are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files refer to the count of ASTER Level-1A scenes that were processed for each pixel or the source of reference data used to replace anomalies. The ASTER Global Water Bodies Database v1 products do not contain QA/QC files.  

- See Section 7 of the ASTER GDEM user guide: <https://lpdaac.usgs.gov/documents/434/ASTGTM_User_Guide_V3.pdf> for additional information regarding the GDEM "NUM" file.  
- See Section 7 of the ASTER Global Water Bodies Database user guide: <https://lpdaac.usgs.gov/documents/436/ASTWBD_User_Guide_V1.pdf> for a comparison with the SRTM Water Body Dataset.  

### 4.12. NASA MEaSUREs NASADEM v1 (30m)  

NASADEM v1 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each NASADEM pixel, as well as the number of input data scenes used to generate the NASADEM v1 data for that pixel.  

- See the NASADEM user guide: <https://lpdaac.usgs.gov/documents/592/NASADEM_User_Guide_V1.pdf> for additional information regarding the NASADEM "NUM" file.  

## 5. Data Caveats  

### 5.1. SSEBop Actual Evapotranspiration (ETa)  

- A list of granule files is not provided for the SSEBop ETa data product. The source data for this product can be obtained by using the download interface at: <https://earlywarning.usgs.gov/fews/datadownloads/Continental%20Africa/Monthly%20ET%20Anomaly>.  

### 5.2. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

- The raw data values within the smoothed eMODIS NDVI product represent scaled byte data with values between 0 and 200. To convert the scaled raw data to smoothed NDVI (smNDVI) data values, the user must apply the following conversion equation:  

      smNDVI = (0.01 * Raw_Data_Value) - 1

- A list of granule files is not provided for the SSEBop ETa data product. The source data for this product can be obtained by using the download interface at: <https://phenology.cr.usgs.gov/get_data_smNDVI.php>.  

### 5.3. ECOSTRESS  

- ECOSTRESS data products are natively stored in swath format. To fulfill AppEEARS requests for ECOSTRESS products, the data are first from the native swath format to a georeferenced output. This requires the use of the requested ECOSTRESS product files and the corresponding ECO1BGEO: <https://doi.org/10.5067/ECOSTRESS/ECO1BGEO.001> files for all products except for ECO1BMAPRAD.001. ECO1BMAPRAD.001 contains latitude and longitude arrays within each file that are then used in the resampling process.  
The conversion leverages the pyresample package’s: <https://pyresample.readthedocs.io/en/stable/> kd_tree algorithm: <https://pyresample.readthedocs.io/en/latest/swath.html#pyresample-kd-tree> using nearest neighbor resampling. The conversion resamples to a Geographic (lat/lon) coordinate reference system (EPSG: 4326), which is defined as the ‘native projection’ option for ECOSTRESS products in AppEEARS.  

### 5.4 S-NPP VIIRS Land Surface Phenology Product (VNP22Q2.001)

- A subset of the science datasets/variables for VNP22Q2.001 are returned in their raw, unscaled form. That is, these variables are returned without having their scale factor and offset applied. AppEEARS visualizations and output summary files are derived using the raw data value, and consequently do not characterize the intended information ("day of year") for the impacted variables. The variables returned in this state include:  

    1. Date_Mid_Greenup_Phase (Cycle 1 and Cycle 2)  
    2. Date_Mid_Senescence_Phase (Cycle 1 and Cycle 2)  
    3. Onset_Greenness_Increase (Cycle 1 and Cycle 2)  
    4. Onset_Greenness_Decrease (Cycle 1 and Cycle 2)  
    5. Onset_Greenness_Maximum (Cycle 1 and Cycle 2)  
    6. Onset_Greenness_Minimum (Cycle 1 and Cycle 2)  

- To convert the raw data to "day of year" (doy) for the above variables, use the following equation:  

      doy = Raw_Data_Value * 1 – (Given_Year - 2000) * 366  

## 6. Documentation

Documentation for data products available through AppEEARS are listed below.

### 6.1. MODIS Land Products(Terra, Aqua, & Combined)

- <https://lpdaac.usgs.gov/product_search/?collections=Combined+MODIS&collections=Terra+MODIS&collections=Aqua+MODIS&view=list>

### 6.2. MODIS Snow Products (Terra and Aqua)  

- <https://nsidc.org/data/modis/data_summaries>

### 6.3. NASA MEaSUREs SRTM v3

- <https://lpdaac.usgs.gov/product_search/?collections=MEaSUREs+SRTM&view=list>

### 6.4. GPW v4  

- <http://sedac.ciesin.columbia.edu/binaries/web/sedac/collections/gpw-v4/gpw-v4-documentation.pdf>

### 6.5. S-NPP NASA VIIRS Land Products  

- <https://lpdaac.usgs.gov/product_search/?collections=S-NPP+VIIRS&view=list>

### 6.6. SMAP Products  

- <http://nsidc.org/data/smap/smap-data.html>

### 6.7. SSEBop Actual Evapotranspiration (ETa)  

- <https://earlywarning.usgs.gov/fews/product/66#documentation>

### 6.8. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

- <https://phenology.cr.usgs.gov/get_data_smNDVI.php>

### 6.9. Daymet  

- <https://doi.org/10.3334/ORNLDAAC/1840>
- <https://daymet.ornl.gov/>

### 6.10. U.S. Landsat ARD  

- <https://www.usgs.gov/land-resources/nli/landsat/us-landsat-analysis-ready-data?qt-science_support_page_related_con=0#qt-science_support_page_related_con>

### 6.11. ECOSTRESS  

- <https://lpdaac.usgs.gov/product_search/?collections=ECOSTRESS&view=list>

### 6.12. ASTER GDEM v3 and Global Water Bodies Database v1  

- <https://doi.org/10.5067/ASTER/ASTGTM.003>
- <https://doi.org/10.5067/ASTER/ASTWBD.001>

### 6.13. NASADEM  

- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NC.001>  
- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NUMNC.001>

## 7. Sample Request Retention  

AppEEARS sample request outputs are available to download for a limited amount of time after completion. Please visit <https://lpdaacsvc.cr.usgs.gov/appeears/help?section=sample-retention> for details.  

## 8. Data Product Citations  

- Wan, Z., Hook, S., Hulley, G. (2015). MYD11A1 MODIS/Aqua Land Surface Temperature/Emissivity Daily L3 Global 1km SIN Grid V006. NASA EOSDIS Land Processes DAAC. Accessed 2021-09-27 from https://doi.org/10.5067/MODIS/MYD11A1.006. Accessed September 27, 2021.

## 9. Software Citation  

AppEEARS Team. (2021). Application for Extracting and Exploring Analysis Ready Samples (AppEEARS). Ver. 2.66. NASA EOSDIS Land Processes Distributed Active Archive Center (LP DAAC), USGS/Earth Resources Observation and Science (EROS) Center, Sioux Falls, South Dakota, USA. Accessed September 27, 2021. https://lpdaacsvc.cr.usgs.gov/appeears

## 10. Feedback  

We value your opinion. Please help us identify what works, what doesn't, and anything we can do to make AppEEARS better by submitting your feedback at https://lpdaacsvc.cr.usgs.gov/appeears/feedback or to LP DAAC User Services at <https://lpdaac.usgs.gov/lpdaac-contact-us/>  
