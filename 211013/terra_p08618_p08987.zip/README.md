# AppEEARS Point Sample Extraction Readme  

## Table of Contents  

1. Request Parameters  
2. Request File Listing  
3. Point Sample Extraction Process  
4. Data Quality  
    4.1. Moderate Resolution Imaging Spectroradiometer (MODIS)  
    4.2. NASA MEaSUREs Shuttle Radar Topography Mission (SRTM) Version 3 (v3)  
    4.3. Gridded Population of the World (GPW) Version 4 (v4)  
    4.4. Suomi National Polar-orbiting Partnership (S-NPP) NASA Visible Infrared Imaging Radiometer Suite (VIIRS)  
    4.5. Soil Moisture Active Passive (SMAP)  
    4.6. MODIS Simplified Surface Energy Balance (SSEBop) Actual Evapotranspiration (ETa)  
    4.7. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  
    4.8. Daymet  
    4.9. U.S. Landsat Analysis Ready Data (ARD)  
    4.10. Ecosystem Spaceborne Thermal Radiometer Experiment on Space Station (ECOSTRESS)  
    4.11. Advanced Spaceborne Thermal Emission and Reflection Radiometer (ASTER) Global Digital Elevation Model (GDEM) Version 3 (v3) and Global Water Bodies Database (WBD) Version 1 (v1)  
    4.12. NASA MEaSUREs NASA Digital Elevation Model (DEM) Version 1 (v1)  
5. Data Caveats  
6. Documentation  
7. Sample Request Retention  
8. Data Product Citations  
9. Software Citation  
10. Feedback  

## 1. Request Parameters  

    Name: Terra_P08618_P08987  

    Date Completed:** 2021-09-27T20:03:23.007750  

    Id: 215ac170-ac0b-43c1-b110-701f77dc9a25  

    Details:  

        Start Date: 12-01-2020  

        End Date: 08-31-2021
    
        Layers:  

            LST_Day_1km (MOD11A1.006)  
            QC_Day (MOD11A1.006)  
            LST_Night_1km (MOD11A1.006)  
            QC_Night (MOD11A1.006)  
    
        Coordinates:  

            P08618, 42.70704043, 0.702655979  
            P08623, 42.69788449, 0.715812352  
            P08625, 42.69801974, 0.728040081  
            P08631, 42.6904707, 0.801226715  
            P08632, 42.67974685, 0.7040284  
            P08633, 42.6813117, 0.77785987  
            P08635, 42.6813431, 0.801878284  
            P08637, 42.67235217, 0.765853928  
            P08639, 42.81772437, 0.832634183  
            P08645, 42.76583726, 0.969616956  
            P08648, 42.75726189, 0.982202676  
            P08649, 42.75712592, 0.994964829  
            P08652, 42.75805862, 1.043669138  
            P08657, 42.74889095, 1.031555831  
            P08658, 42.7490716, 1.043670866  
            P08667, 42.73883809, 0.9837655  
            P08670, 42.73994465, 1.056076911  
            P08675, 42.74082835, 1.10502687  
            P08676, 42.72680324, 0.825128606  
            P08681, 42.73232723, 1.091995601  
            P08682, 42.73226519, 1.11762507  
            P08693, 42.71454704, 1.105851376  
            P08694, 42.71457569, 1.117964577  
            P08695, 42.71426674, 1.13154113  
            P08696, 42.70230026, 0.97179927  
            P08700, 42.70512738, 1.118396626  
            P08702, 42.69216541, 0.886922526  
            P08703, 42.6925713, 0.924373041  
            P08710, 42.68389587, 0.935634857  
            P08711, 42.68607267, 1.058002216  
            P08714, 42.68652733, 1.107203641  
            P08719, 42.67459513, 0.924263796  
            P08725, 42.67629904, 1.045650904  
            P08729, 42.6663966, 1.059078701  
            P08732, 42.66880353, 1.095160604  
            P08733, 42.66832211, 1.107402406  
            P08739, 42.69735408, 1.215602887  
            P08740, 42.69752949, 1.227476717  
            P08742, 42.68887282, 1.24073539  
            P08743, 42.6892453, 1.252712024  
            P08746, 42.67992294, 1.229136883  
            P08747, 42.6804455, 1.241424822  
            P08748, 42.680091, 1.253566671  
            P08750, 42.68112173, 1.313929622  
            P08752, 42.67060906, 1.229560033  
            P08755, 42.67114467, 1.241528488  
            P08756, 42.67040306, 1.290081493  
            P08762, 42.66346795, 0.779471891  
            P08767, 42.62742015, 0.779912774  
            P08769, 42.62804631, 0.791804646  
            P08782, 42.59113751, 0.767356654  
            P08789, 42.56386539, 0.769438394  
            P08792, 42.53625479, 0.759255748  
            P08798, 42.66478154, 0.863178434  
            P08800, 42.66442141, 0.887936  
            P08801, 42.66518421, 0.901015062  
            P08807, 42.66694792, 0.973425295  
            P08808, 42.65624532, 0.876281041  
            P08812, 42.65639757, 0.91247394  
            P08814, 42.65773965, 0.961475119  
            P08819, 42.65934803, 1.058163337  
            P08821, 42.6602701, 1.132000166  
            P08826, 42.64692052, 0.888699187  
            P08834, 42.64901856, 1.022351716  
            P08836, 42.64989818, 1.046843921  
            P08840, 42.65027775, 1.071364501  
            P08843, 42.6387618, 0.925650897  
            P08844, 42.64023032, 0.973975802  
            P08847, 42.64031496, 1.01064987  
            P08848, 42.64030124, 1.022335185  
            P08852, 42.6416311, 1.071802445  
            P08855, 42.64252799, 1.119784653  
            P08857, 42.62982541, 0.937935527  
            P08860, 42.63181718, 1.035348221  
            P08861, 42.63219878, 1.047129348  
            P08867, 42.63259762, 1.084069788  
            P08869, 42.63309751, 1.096225851  
            P08876, 42.62465224, 1.133529139  
            P08879, 42.61409655, 1.060277445  
            P08882, 42.61500095, 1.098094114  
            P08884, 42.61492299, 1.144951347  
            P08886, 42.60505168, 1.085755537  
            P08888, 42.60577075, 1.109529291  
            P08896, 42.59626151, 1.085695601  
            P08898, 42.5967708, 1.097344593  
            P08901, 42.58714381, 1.023931711  
            P08902, 42.58704709, 1.036109346  
            P08905, 42.58766911, 1.098048059  
            P08909, 42.57429867, 0.842098118  
            P08911, 42.57464185, 0.93047085  
            P08912, 42.57528748, 0.938807999  
            P08917, 42.57744987, 1.036776192  
            P08919, 42.57857734, 1.048475082  
            P08920, 42.57835004, 1.061605509  
            P08924, 42.57909009, 1.110201718  
            P08925, 42.57902515, 1.122681379  
            P08928, 42.56464927, 0.818078509  
            P08932, 42.56683836, 0.9277076  
            P08934, 42.56738878, 0.951799282  
            P08938, 42.57042195, 1.13517181  
            P08939, 42.55620705, 0.830650839  
            P08947, 42.55737701, 0.903634643  
            P08948, 42.55805382, 0.927961877  
            P08951, 42.55948738, 1.061812056  
            P08953, 42.56122893, 1.098559243  
            P08956, 42.56081725, 1.1238366  
            P08961, 42.54823102, 0.855175718  
            P08964, 42.54772168, 0.867445228  
            P08969, 42.54885901, 0.928436655  
            P08970, 42.55089335, 1.050495146  
            P08972, 42.55107702, 1.098928429  
            P08973, 42.55148305, 1.111497921  
            P08974, 42.53858311, 0.831565712  
            P08978, 42.5429157, 1.098238421  
            P08980, 42.54296139, 1.12339725  
            P08982, 42.53316814, 1.111075898  
            P08983, 42.53334775, 1.123648665  
            P08985, 42.53438314, 1.135769875  
            P08986, 42.52375933, 1.110641167  
            P08987, 42.5238865, 1.123858864  
    
    Version: This request was processed by AppEEARS version 2.66  

## 2. Request File Listing  

- Comma-separated values file with data extracted for a specific product
  - Terra-P08618-P08987-MOD11A1-006-results.csv
- Text file with data pool URLs for all source granules used in the extraction
  - Terra-P08618-P08987-granule-list.txt
- JSON request file which can be used in AppEEARS to create a new request
  - Terra-P08618-P08987-request.json
- xml file
  - Terra-P08618-P08987-MOD11A1-006-metadata.xml  

## 3. Point Sample Extraction Process  

Datasets available in AppEEARS are served via OPeNDAP (Open-source Project for a Network Data Access Protocol) services. OPeNDAP services allow users to concisely pull pixel values from datasets via HTTPS requests. A middleware layer has been developed to interact with the OPeNDAP services. The middleware make it possible to extract scaled data values, with associated information, for pixels corresponding to a given coordinate and date range.

**NOTE:**  

- Requested date ranges may not match the reference date for multi-day products. AppEEARS takes an inclusive approach when extracting data for sample requests, often returning data that extends beyond the requested date range. This approach ensures that the returned data includes records for the entire requested date range.  
- For multi-day (8-day, 16-day, Monthly, Yearly) MODIS and S-NPP NASA VIIRS datasets, the date field in the data tables reflects the first day of the composite period.  
- If selected, the SRTM v3, ASTER GDEM v3 and Global Water Bodies Database v1, and NASADEM v1 product will be extracted regardless of the time period specified in AppEEARS because it is a static dataset. The date field in the data tables reflects the nominal SRTM date of February 11, 2000.  
- If the visualizations indicate that there are no data to display, proceed to downloading the .csv output file. Data products that have both categorical and continuous data values (e.g. MOD15A2H) are not able to be displayed within the visualizations within AppEEARS.  

## 4. Data Quality  

When available, AppEEARS extracts and returns quality assurance (QA) data for each data file returned regardless of whether the user requests it. This is done to ensure that the user possesses the information needed to determine the usability and usefulness of the data they get from AppEEARS. Most data products available through AppEEARS have an associated QA data layer. Some products have more than one QA data layer to consult. See below for more information regarding data collections/products and their associated QA data layers.  

### 4.1. MODIS (Terra, Aqua, & Combined)

All MODIS land products, as well as the MODIS Snow Cover Daily product, include quality assurance (QA) information designed to help users understand and make best use of the data that comprise each product. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values but also the decoded QA information associated with each pixel/data value extracted.  

- See the MODIS Land Products QA Tutorials: <https://lpdaac.usgs.gov/resources/e-learning/> for more QA information regarding each MODIS land product suite.  
- See the MODIS Snow Cover Daily product user guide for information regarding QA utilization and interpretation.  

### 4.2. NASA MEaSUREs SRTM v3 (30m & 90m)  

SRTM v3 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each SRTM pixel, as well as the number of input data scenes used to generate the SRTM v3 data for that pixel.  

- See the user guide: <https://lpdaac.usgs.gov/documents/179/SRTM_User_Guide_V3.pdf> for additional information regarding the SRTM "NUM" file.  

### 4.3. GPW v4  

The GPW Population Count and Population Density data layers are accompanied by two Data Quality Indicators datasets. The Data Quality Indicators were created to provide context for the population count and density grids, and to provide explicit information on the spatial precision of the input boundary data. The data context grid (data-context1) explains pixels with "0" population estimate in the population count and density grids, based on information included in the census documents. The mean administrative unit area grid (mean-admin-area2) measures the mean input unit size in square kilometers. It provides a quantitative surface that indicates the size of the input unit(s) from which the population count and density grids were created.  

### 4.4. S-NPP NASA VIIRS

All S-NPP NASA VIIRS land products include quality information designed to help users understand and make best use of the data that comprise each product. For product-specific information, see the link to the S-NPP VIIRS products table provided in section 5.  

**NOTE:**  

- The S-NPP NASA VIIRS Surface Reflectance data products VNP09A1 and VNP09H1 contain two quality layers: `SurfReflect_State` and `SurfReflect_QC`. Both quality layers are provided to the user with the request results. Due to changes implemented on August 21, 2017 for forward processed data, there are differences in values for the `SurfReflect_QC` layer in VNP09A1 and `SurfReflect_QC_500` in VNP09H1.  
- Refer to the S-NPP NASA VIIRS Surface Reflectance User's Guide Version 1.1: <https://lpdaac.usgs.gov/documents/123/VNP09_User_Guide_V1.1.pdf> for information on how to decode the `SurfReflect_QC` quality layer for data processed before August 21, 2017. For data processed on or after August 21, 2017, refer to the S-NPP NASA VIIRS Surface Reflectance User's guide Version 1.6: <https://lpdaac.usgs.gov/documents/124/VNP09_User_Guide_V1.6.pdf>  

### 4.5. SMAP  

SMAP products provide multiple means to assess quality. Each data product contains bit flags, uncertainty measures, and file-level metadata that provide quality information. Results downloaded from AppEEARS and/or data directly requested via middleware services contain not only the requested pixel/data values, but also the decoded bit flag information associated with each pixel/data value extracted. For additional information regarding the specific bit flags, uncertainty measures, and file-level metadata contained in this product, refer to the Quality Assessment section of the user guide for the specific SMAP data product in your request: <https://nsidc.org/data/smap/smap-data.html>  

### 4.6. SSEBop Actual Evapotranspiration (ETa)  

The SSEBop evapotranspiration monthly product does not have associated quality indicators or data layers. The data are considered to satisfy the quality standards relative to the purpose for which the data were collected.

### 4.7. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

The smoothed eMODIS NDVI product does not have associated quality indicators or data layers. The data are considered to satisfy the quality standards relative to the purpose for which the data were collected.  

### 4.8. Daymet  

Daymet station-level daily weather observation data and the corresponding Daymet model predicted data for three Daymet model parameters: minimum temperature (tmin), maximum temperature (tmax), and daily total precipitation (prcp) are available. These data provide information into the regional accuracy of the Daymet model for the three station-level input parameters. Corresponding comma separated value (.csv) files that contain metadata for every surface weather station for the variable-year combinations are also available. <https://doi.org/10.3334/ORNLDAAC/1850>

### 4.9. U.S. Landsat ARD  

Quality assessment bands for the U.S. Landsat ARD data products are produced from Level 1 inputs with additional calculations derived from higher-level processing. A pixel quality assessment band describing the general state of each pixel is supplied with each AppEEARS request. In addition to the pixel quality assessment band, Landsat ARD data products also have additional bands that can be used to evaluate the usability and usefulness of the data. These include bands that characterize radiometric saturation, as well as parameters specific to atmospheric correction. Refer to the U.S. Landsat ARD Data Format Control Book (DFCB): <https://www.usgs.gov/media/files/landsat-analysis-ready-data-ard-data-format-control-book-dfcb> for a full description of the quality assessment bands for each product (L4-L8) as well as guidance on interpreting each band’s bit-packed data values.

### 4.10. ECOSTRESS  

Quality information varies by product for the ECOSTRESS product suite. Quality information for ECO2LSTE.001, including the bit definition index for the quality layer, is provided in section 2.4 of the User Guide: <https://lpdaac.usgs.gov/documents/423/ECO2_User_Guide_V1.pdf>. Results downloaded from AppEEARS contain the requested pixel/data values and also the decoded QA information associated with each pixel/data value extracted. No quality flags are produced for the ECO3ETPTJPL.001, ECO4WUE.001, or ECO4ESIPTJPL.001 products. Instead, the quality flags of the source data are available in the ECO3ANCQA.001 data product and a cloud mask is available in the ECO2CLD.001 product. The `ETinst` layer in the ECO3ETPTJPL.001 product does include an associated uncertainty layer that is provided with each request for ‘ETinst’ in AppEEARS. Each radiance layer in the ECO1BMAPRAD.001 product has a linked quality layer (Data Quality Indicators). ECO2CLD.001 and ECO3ANCQA.001 are separate quality products that are also available for download in AppEEARS.  

### 4.11. ASTER GDEM v3 and Global Water Bodies Database v1  

ASTER GDEM v3 data are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files refer to the count of ASTER Level-1A scenes that were processed for each pixel or the source of reference data used to replace anomalies. The ASTER Global Water Bodies Database v1 products do not contain QA/QC files.  

- See Section 7 of the ASTER GDEM user guide: <https://lpdaac.usgs.gov/documents/434/ASTGTM_User_Guide_V3.pdf> for additional information regarding the GDEM "NUM" file.  
- See Section 7 of the ASTER Global Water Bodies Database user guide: <https://lpdaac.usgs.gov/documents/436/ASTWBD_User_Guide_V1.pdf> for a comparison with the SRTM Water Body Dataset.  

### 4.12. NASA MEaSUREs NASADEM v1 (30m)  

NASADEM v1 products are accompanied by an ancillary "NUM" file in place of the QA/QC files. The "NUM" files indicate the source of each NASADEM pixel, as well as the number of input data scenes used to generate the NASADEM v1 data for that pixel.  

- See the NASADEM user guide: <https://lpdaac.usgs.gov/documents/592/NASADEM_User_Guide_V1.pdf> for additional information regarding the NASADEM "NUM" file.  

## 5. Data Caveats  

### 5.1. SSEBop Actual Evapotranspiration (ETa)  

- A list of granule files is not provided for the SSEBop ETa data product. The source data for this product can be obtained by using the download interface at: <https://earlywarning.usgs.gov/fews/datadownloads/Continental%20Africa/Monthly%20ET%20Anomaly>.  

### 5.2. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

- The raw data values within the smoothed eMODIS NDVI product represent scaled byte data with values between 0 and 200. To convert the scaled raw data to smoothed NDVI (smNDVI) data values, the user must apply the following conversion equation:  

      smNDVI = (0.01 * Raw_Data_Value) - 1

- A list of granule files is not provided for the SSEBop ETa data product. The source data for this product can be obtained by using the download interface at: <https://phenology.cr.usgs.gov/get_data_smNDVI.php>.  

### 5.3. ECOSTRESS  

- ECOSTRESS data products are natively stored in swath format. To fulfill AppEEARS requests for ECOSTRESS products, the data are first from the native swath format to a georeferenced output. This requires the use of the requested ECOSTRESS product files and the corresponding ECO1BGEO: <https://doi.org/10.5067/ECOSTRESS/ECO1BGEO.001> files for all products except for ECO1BMAPRAD.001. ECO1BMAPRAD.001 contains latitude and longitude arrays within each file that are then used in the resampling process.  
The conversion leverages the pyresample package’s: <https://pyresample.readthedocs.io/en/stable/> kd_tree algorithm: <https://pyresample.readthedocs.io/en/latest/swath.html#pyresample-kd-tree> using nearest neighbor resampling. The conversion resamples to a Geographic (lat/lon) coordinate reference system (EPSG: 4326), which is defined as the ‘native projection’ option for ECOSTRESS products in AppEEARS.  

### 5.4 S-NPP VIIRS Land Surface Phenology Product (VNP22Q2.001)

- A subset of the science datasets/variables for VNP22Q2.001 are returned in their raw, unscaled form. That is, these variables are returned without having their scale factor and offset applied. AppEEARS visualizations and output summary files are derived using the raw data value, and consequently do not characterize the intended information ("day of year") for the impacted variables. The variables returned in this state include:  

    1. Date_Mid_Greenup_Phase (Cycle 1 and Cycle 2)  
    2. Date_Mid_Senescence_Phase (Cycle 1 and Cycle 2)  
    3. Onset_Greenness_Increase (Cycle 1 and Cycle 2)  
    4. Onset_Greenness_Decrease (Cycle 1 and Cycle 2)  
    5. Onset_Greenness_Maximum (Cycle 1 and Cycle 2)  
    6. Onset_Greenness_Minimum (Cycle 1 and Cycle 2)  

- To convert the raw data to "day of year" (doy) for the above variables, use the following equation:  

      doy = Raw_Data_Value * 1 – (Given_Year - 2000) * 366  

## 6. Documentation

Documentation for data products available through AppEEARS are listed below.

### 6.1. MODIS Land Products(Terra, Aqua, & Combined)

- <https://lpdaac.usgs.gov/product_search/?collections=Combined+MODIS&collections=Terra+MODIS&collections=Aqua+MODIS&view=list>

### 6.2. MODIS Snow Products (Terra and Aqua)  

- <https://nsidc.org/data/modis/data_summaries>

### 6.3. NASA MEaSUREs SRTM v3

- <https://lpdaac.usgs.gov/product_search/?collections=MEaSUREs+SRTM&view=list>

### 6.4. GPW v4  

- <http://sedac.ciesin.columbia.edu/binaries/web/sedac/collections/gpw-v4/gpw-v4-documentation.pdf>

### 6.5. S-NPP NASA VIIRS Land Products  

- <https://lpdaac.usgs.gov/product_search/?collections=S-NPP+VIIRS&view=list>

### 6.6. SMAP Products  

- <http://nsidc.org/data/smap/smap-data.html>

### 6.7. SSEBop Actual Evapotranspiration (ETa)  

- <https://earlywarning.usgs.gov/fews/product/66#documentation>

### 6.8. eMODIS Smoothed Normalized Difference Vegetation Index (NDVI)  

- <https://phenology.cr.usgs.gov/get_data_smNDVI.php>

### 6.9. Daymet  

- <https://doi.org/10.3334/ORNLDAAC/1840>
- <https://daymet.ornl.gov/>

### 6.10. U.S. Landsat ARD  

- <https://www.usgs.gov/land-resources/nli/landsat/us-landsat-analysis-ready-data?qt-science_support_page_related_con=0#qt-science_support_page_related_con>

### 6.11. ECOSTRESS  

- <https://lpdaac.usgs.gov/product_search/?collections=ECOSTRESS&view=list>

### 6.12. ASTER GDEM v3 and Global Water Bodies Database v1  

- <https://doi.org/10.5067/ASTER/ASTGTM.003>
- <https://doi.org/10.5067/ASTER/ASTWBD.001>

### 6.13. NASADEM  

- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NC.001>  
- <https://doi.org/10.5067/MEaSUREs/NASADEM/NASADEM_NUMNC.001>

## 7. Sample Request Retention  

AppEEARS sample request outputs are available to download for a limited amount of time after completion. Please visit <https://lpdaacsvc.cr.usgs.gov/appeears/help?section=sample-retention> for details.  

## 8. Data Product Citations  

- Wan, Z., Hook, S., Hulley, G. (2015). MOD11A1 MODIS/Terra Land Surface Temperature/Emissivity Daily L3 Global 1km SIN Grid V006. NASA EOSDIS Land Processes DAAC. Accessed 2021-09-27 from https://doi.org/10.5067/MODIS/MOD11A1.006. Accessed September 27, 2021.

## 9. Software Citation  

AppEEARS Team. (2021). Application for Extracting and Exploring Analysis Ready Samples (AppEEARS). Ver. 2.66. NASA EOSDIS Land Processes Distributed Active Archive Center (LP DAAC), USGS/Earth Resources Observation and Science (EROS) Center, Sioux Falls, South Dakota, USA. Accessed September 27, 2021. https://lpdaacsvc.cr.usgs.gov/appeears

## 10. Feedback  

We value your opinion. Please help us identify what works, what doesn't, and anything we can do to make AppEEARS better by submitting your feedback at https://lpdaacsvc.cr.usgs.gov/appeears/feedback or to LP DAAC User Services at <https://lpdaac.usgs.gov/lpdaac-contact-us/>  
